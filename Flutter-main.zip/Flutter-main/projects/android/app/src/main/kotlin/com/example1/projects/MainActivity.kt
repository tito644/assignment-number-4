package com.example1.projects

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
